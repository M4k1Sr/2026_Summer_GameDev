#pragma once
class Orc
{
};

