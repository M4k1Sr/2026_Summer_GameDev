#pragma once
class Diablo
{
};

