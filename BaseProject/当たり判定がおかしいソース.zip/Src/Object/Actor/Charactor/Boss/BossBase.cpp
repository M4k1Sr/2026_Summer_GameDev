#include "../../../../Utility/AsoUtility.h"
#include "../../../../Utility/MatrixUtility.h"
#include "../Player.h"
#include "BossBase.h"

BossBase::BossBase(const BossBase::BossData& data)
	:
	CharactorBase(),
	type_(data.type),
	stateBase_(0),
	player_()
{
	// �������W�̐ݒ�
	transform_.pos = data.defaultPos;
}

BossBase::~BossBase(void)
{
}

void BossBase::SetPlayer(Player* player)
{
	player_ = player;
}

void BossBase::ChangeState(int state)
{

	stateBase_ = state;

	// �e��ԑJ�ڂ̏�������
	stateChanges_[stateBase_]();

}


