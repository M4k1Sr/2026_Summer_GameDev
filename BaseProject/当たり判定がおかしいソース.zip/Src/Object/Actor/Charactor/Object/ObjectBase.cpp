#include "../../../../Utility/AsoUtility.h"
#include "ObjectBase.h"

ObjectBase::ObjectBase(const ObjectBase::ObjectData& data)
	:
	CharactorBase(),
	type_(data.type),
	stateBase_(0)
{
	// �������W�̐ݒ�
	transform_.pos = data.defaultPos;
}

ObjectBase::~ObjectBase(void)
{
}

bool ObjectBase::GetFlag(void) const
{
	return isGimmick_;
}

void ObjectBase::SetFlag(bool isGimmick)
{
	isGimmick_ = isGimmick;
}

void ObjectBase::ChangeState(int state)
{

	stateBase_ = state;

	// �e��ԑJ�ڂ̏�������
	stateChanges_[stateBase_]();

}

